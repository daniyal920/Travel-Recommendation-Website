// Dropdown to filter recommendations based on country
document.getElementById('country-select').addEventListener('change', function () {
  const selectedCountry = this.value;
  document.querySelectorAll('.country').forEach((country) => {
    country.style.display = country.id === selectedCountry ? 'block' : 'none';
  });
});

// Email validation and submission handling in the Contact Us form
document.querySelector('form').addEventListener('submit', function (event) {
  event.preventDefault();
  const email = document.getElementById('email').value;
  if (!email.includes('@')) {
    alert('Please enter a valid email address.');
  } else {
    alert('Thank you for contacting us!');
  }
});

// Interactive navigation highlight (optional, for better UX)
document.querySelectorAll('nav ul li a').forEach((link) => {
  link.addEventListener('click', function () {
    document.querySelectorAll('nav ul li a').forEach((navLink) => {
      navLink.classList.remove('active');
    });
    this.classList.add('active');
  });
});

// Scroll to sections smoothly when navigation links are clicked (optional)
document.querySelectorAll('nav ul li a').forEach((link) => {
  link.addEventListener('click', function (event) {
    event.preventDefault();
    const sectionId = this.getAttribute('href').replace('.html', '');
    document.querySelector(sectionId).scrollIntoView({ behavior: 'smooth' });
  });
});

// Dynamic introduction content on the Home Page (optional enhancement)
document.addEventListener('DOMContentLoaded', function () {
  const introSection = document.getElementById('intro');
  if (introSection) {
    introSection.innerHTML += `
      <p><strong>Start exploring beautiful destinations now!</strong></p>
    `;
  }
});
